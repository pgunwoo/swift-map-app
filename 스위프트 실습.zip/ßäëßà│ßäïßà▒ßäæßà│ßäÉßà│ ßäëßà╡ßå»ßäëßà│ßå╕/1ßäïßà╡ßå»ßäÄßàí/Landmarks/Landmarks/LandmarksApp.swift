//
//  LandmarksApp.swift
//  Landmarks
//
//  Created by 박건우 on 8/20/24.
//

import SwiftUI

@main
struct LandmarksApp: App {
    @State private var modelData = ModelData()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(modelData)
        }
    }
}
